typedef enum {p, q, r, s} Third;

Third y(First q);
void z(Third r);
