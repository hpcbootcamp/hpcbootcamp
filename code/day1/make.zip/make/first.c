#include "first.h"
#include "fourth.h"

First w(void) {
  First temp;
  Fourth july = 4;
  temp.a = july;
  return temp;
}
