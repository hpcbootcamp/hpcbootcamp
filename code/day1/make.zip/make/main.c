#include "first.h"
#include "second.h"
#include "third.h"
#include "fourth.h"

#include <stdio.h>

int main() {
  First b = w();
  Second a;
  Fourth c;

  x(a);
  z(y(b));
  c = 12345;

  printf("Success! Now implement clean and make.tgz targets.\n");

  return c - c;
}
