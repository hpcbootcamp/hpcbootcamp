typedef struct {
  double d;
  First f;
} Second;

void x(Second s);

