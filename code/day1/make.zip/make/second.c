#include "first.h"
#include "second.h"

void x(Second s) {
  Second t;
  First q;
  t.f = q;
  t.d = t.f.a;
}
