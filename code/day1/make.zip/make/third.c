#include "first.h"
#include "second.h"
#include "third.h"

Third y(First q) {
  Second s;
  Third t = r;
  return s.f.a + t;
}

void z(Third r) {
}
