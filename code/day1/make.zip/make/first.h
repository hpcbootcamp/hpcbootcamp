typedef struct {
  int a;
  char b;
  float c;
} First;

First w(void);
