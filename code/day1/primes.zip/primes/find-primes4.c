#include <stdio.h>
#define MAX 500000

/* This program is from "More Programming Pearls", Jon Bentley, 1988 */

int prime(int n);

int prime(int n) {
  int i;

  if (n % 2 == 0)
    return n == 2;

  if (n % 3 == 0)
    return n == 3;

  if (n % 5 == 0)
    return n == 5;

  for (i= 7; i * i <= n; i += 2)
    if (n % i == 0)
      return 0;

  return 1;
}

int main() {
  int i;

  for (i= 2; i <= MAX; i++)
    if (prime(i))
      printf("%d is prime\n", i);

  return 0;
}
